export type Language = 'bn' | 'en';

export interface UserProfile {
  email: string;
  name: string;
  photoUrl?: string;
  loginTime: string;
}

export type PlaystyleType = 'all' | 'shotgun' | 'smg' | 'ar' | 'sniper';

export interface SensiResult {
  model: string;
  ram: string;
  rom: string;
  android: string;
  playstyle: PlaystyleType;
  general: number;
  redDot: number;
  scope2: number;
  scope4: number;
  sniperScope: number;
  freeLook: number;
  recommendedDpi: number;
  fireButtonSize: number;
  buttonPosition: { x: number; y: number };
  pointerSpeed: string;
  refreshRate: string;
  graphics: string;
  headshotRate: number;
  timestamp: number;
}

export interface SavedSetup {
  id: string;
  name: string;
  result: SensiResult;
  savedAt: string;
}
