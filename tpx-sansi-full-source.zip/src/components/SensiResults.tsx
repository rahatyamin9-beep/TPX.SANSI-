import React, { useState } from 'react';
import {
  CheckCheck,
  Copy,
  Save,
  HelpCircle,
  Crosshair,
  Sliders,
  Sparkles,
  Gauge,
  Flame
} from 'lucide-react';
import { Language, SensiResult } from '../types';
import { playClickSound } from '../utils/audio';

interface SensiResultsProps {
  result: SensiResult;
  onSave: () => void;
  onOpenDpiGuide: () => void;
  onOpenSimulator: () => void;
  lang: Language;
}

export const SensiResults: React.FC<SensiResultsProps> = ({
  result,
  onSave,
  onOpenDpiGuide,
  onOpenSimulator,
  lang
}) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'sensi' | 'hud'>('sensi');

  const copyToClipboard = () => {
    playClickSound();
    const text = `🔥 TPX SANSI VIP - 200 SCALE FREE FIRE SETUP 🔥
📱 Device: ${result.model.toUpperCase()}
⚡ Specs: ${result.ram} | ${result.rom}
🤖 OS: ${result.android.toUpperCase()}
🎯 Playstyle: ${result.playstyle.toUpperCase()}

📊 200-SCALE SENSITIVITY:
• General: ${result.general} / 200
• Red Dot: ${result.redDot} / 200
• 2X Scope: ${result.scope2} / 200
• 4X Scope: ${result.scope4} / 200
• Sniper Scope: ${result.sniperScope} / 200
• Free Look: ${result.freeLook} / 200

⚙️ CONTROLS & DISPLAY:
• Fire Button Size: ${result.fireButtonSize}%
• Button Position: Bottom-Right (${result.buttonPosition.x}%, ${result.buttonPosition.y}%)
• Recommended DPI: ${result.recommendedDpi}
• Pointer Speed: ${result.pointerSpeed}
• Refresh Rate: ${result.refreshRate}

🌐 Verified on www.tpxsansi.com`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const sensiItems = [
    { label: lang === 'bn' ? 'General (জেনারেল)' : 'General', val: result.general, color: 'from-[#ff003c] to-[#ff4d79]' },
    { label: lang === 'bn' ? 'Red Dot (রেড ডট)' : 'Red Dot', val: result.redDot, color: 'from-[#ff003c] to-[#ff6b8b]' },
    { label: lang === 'bn' ? '2x Scope (২x স্কোপ)' : '2x Scope', val: result.scope2, color: 'from-[#ff003c] to-[#e60036]' },
    { label: lang === 'bn' ? '4x Scope (৪x স্কোপ)' : '4x Scope', val: result.scope4, color: 'from-[#ff003c] to-[#b3002a]' },
    { label: lang === 'bn' ? 'Sniper Scope (স্নাইপার)' : 'Sniper Scope', val: result.sniperScope, color: 'from-[#00ff88] to-[#00b35f]' },
    { label: lang === 'bn' ? 'Free Look (ফ্রি লুক)' : 'Free Look', val: result.freeLook, color: 'from-[#38bdf8] to-[#0284c7]' }
  ];

  return (
    <div className="mt-6 bg-[#090a0f] border border-[#262c3d] rounded-2xl p-4 sm:p-5 border-l-4 border-l-[#ff003c] shadow-2xl relative animate-fadeIn">
      {/* Top Verified Badge */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pb-3 border-b border-[#262c3d]">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#00ff88]/15 border border-[#00ff88] text-[#00ff88] text-xs font-bold font-orbitron tracking-wide glow-green">
          <Sparkles className="w-3.5 h-3.5" />
          <span>200 SCALE VERIFIED: {result.model.toUpperCase()}</span>
        </div>

        <div className="flex items-center gap-1 text-[11px] text-[#ff003c] font-orbitron font-semibold">
          <Flame className="w-3.5 h-3.5 fill-[#ff003c]" />
          <span>{result.headshotRate}% HEADSHOT RATE</span>
        </div>
      </div>

      {/* Target Specs Summary Bar */}
      <div className="grid grid-cols-3 gap-2 my-3 p-2.5 rounded-xl bg-[#12151e] border border-[#262c3d] text-center">
        <div>
          <span className="text-[10px] text-gray-400 block">{lang === 'bn' ? 'টার্গেট ফোন' : 'Target Phone'}</span>
          <span className="text-xs font-bold text-white truncate block">{result.model.toUpperCase()}</span>
        </div>
        <div className="border-x border-[#262c3d]">
          <span className="text-[10px] text-gray-400 block">{lang === 'bn' ? 'হার্ডওয়্যার' : 'Hardware'}</span>
          <span className="text-xs font-bold text-white truncate block">{result.ram}</span>
        </div>
        <div>
          <span className="text-[10px] text-gray-400 block">{lang === 'bn' ? 'অপারেটিং সিস্টেম' : 'Android OS'}</span>
          <span className="text-xs font-bold text-white truncate block">{result.android.toUpperCase()}</span>
        </div>
      </div>

      {/* Tab Selector */}
      <div className="flex border-b border-[#262c3d] mb-4">
        <button
          onClick={() => {
            playClickSound();
            setActiveTab('sensi');
          }}
          className={`flex-1 py-2 text-xs font-bold font-orbitron flex items-center justify-center gap-1.5 border-b-2 transition ${
            activeTab === 'sensi'
              ? 'border-[#ff003c] text-white bg-[#ff003c]/10'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>{lang === 'bn' ? '২০০ স্কেল সেন্সিটিভিটি' : '200 Scale Sensi'}</span>
        </button>
        <button
          onClick={() => {
            playClickSound();
            setActiveTab('hud');
          }}
          className={`flex-1 py-2 text-xs font-bold font-orbitron flex items-center justify-center gap-1.5 border-b-2 transition ${
            activeTab === 'hud'
              ? 'border-[#00ff88] text-white bg-[#00ff88]/10'
              : 'border-transparent text-gray-400 hover:text-white'
          }`}
        >
          <Gauge className="w-3.5 h-3.5" />
          <span>{lang === 'bn' ? 'DPI & বাটন সাইজ' : 'DPI & Button HUD'}</span>
        </button>
      </div>

      {activeTab === 'sensi' ? (
        /* SENSITIVITY BREAKDOWN */
        <div className="space-y-3.5">
          {sensiItems.map((item) => {
            const percentage = Math.round((item.val / 200) * 100);
            return (
              <div key={item.label} className="bg-[#12151e] p-2.5 rounded-xl border border-[#262c3d]/60">
                <div className="flex justify-between items-center text-xs mb-1.5">
                  <span className="text-gray-300 font-medium">{item.label}</span>
                  <div className="flex items-center gap-1.5">
                    <span className="font-orbitron font-extrabold text-[#ff003c] text-sm">{item.val}</span>
                    <span className="text-[10px] text-gray-500 font-mono">/ 200</span>
                  </div>
                </div>
                {/* Visual Progress Bar */}
                <div className="w-full h-2 bg-[#090a0f] rounded-full overflow-hidden p-0.5 border border-[#262c3d]">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${item.color} transition-all duration-700 ease-out`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* DPI & HUD SETTINGS */
        <div className="space-y-3">
          <div className="bg-[#12151e] p-3 rounded-xl border border-[#262c3d] flex items-center justify-between">
            <div>
              <div className="text-xs text-gray-300 font-semibold flex items-center gap-1.5">
                <span>{lang === 'bn' ? 'রেকমেন্ডেড DPI (Smallest Width)' : 'Recommended DPI'}</span>
                <button
                  type="button"
                  onClick={onOpenDpiGuide}
                  className="text-[#00ff88] hover:underline"
                  title="How to set DPI safely"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                </button>
              </div>
              <span className="text-[10px] text-gray-500">{lang === 'bn' ? 'ডিভাইসের আসল টাচ রেসপন্স বাড়ায়' : 'Boosts touch response speed'}</span>
            </div>
            <div className="text-right">
              <span className="font-orbitron font-extrabold text-[#00ff88] text-base">{result.recommendedDpi}</span>
              <span className="block text-[9px] text-gray-400">DPI</span>
            </div>
          </div>

          <div className="bg-[#12151e] p-3 rounded-xl border border-[#262c3d] flex items-center justify-between">
            <div>
              <div className="text-xs text-gray-300 font-semibold">{lang === 'bn' ? 'ফায়ার বাটন সাইজ' : 'Fire Button Size'}</div>
              <span className="text-[10px] text-gray-500">{lang === 'bn' ? 'পারফেক্ট ড্র্যাগ ট্রাভেলের জন্য' : 'Optimal drag lift clearance'}</span>
            </div>
            <div className="text-right">
              <span className="font-orbitron font-extrabold text-[#ff003c] text-base">{result.fireButtonSize}%</span>
            </div>
          </div>

          <div className="bg-[#12151e] p-3 rounded-xl border border-[#262c3d] flex items-center justify-between">
            <div>
              <div className="text-xs text-gray-300 font-semibold">{lang === 'bn' ? 'বাটন পজিশন' : 'HUD Button Placement'}</div>
              <span className="text-[10px] text-gray-500">{lang === 'bn' ? 'স্ক্রিনের নিচের ডান কোণা' : 'Bottom Right Thumb Zone'}</span>
            </div>
            <div className="text-right">
              <span className="font-mono text-xs text-gray-200">X: {result.buttonPosition.x}% | Y: {result.buttonPosition.y}%</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-[#12151e] p-2.5 rounded-xl border border-[#262c3d]">
              <span className="text-[10px] text-gray-500 block">{lang === 'bn' ? 'পয়েন্টার স্পিড' : 'Pointer Speed'}</span>
              <span className="font-semibold text-white text-[11px]">{result.pointerSpeed}</span>
            </div>
            <div className="bg-[#12151e] p-2.5 rounded-xl border border-[#262c3d]">
              <span className="text-[10px] text-gray-500 block">{lang === 'bn' ? 'গ্রাফিক্স রেটিং' : 'Graphics Setting'}</span>
              <span className="font-semibold text-white text-[11px]">{result.graphics}</span>
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-4 pt-3 border-t border-[#262c3d]">
        {/* Save Setup */}
        <button
          onClick={onSave}
          className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-[#00c853] hover:bg-[#00b047] text-white font-bold text-xs shadow-lg shadow-[#00c853]/20 transition active:scale-98 cursor-pointer"
        >
          <Save className="w-4 h-4" />
          <span>{lang === 'bn' ? 'Save Setup' : 'Save Setup'}</span>
        </button>

        {/* Copy Setup */}
        <button
          onClick={copyToClipboard}
          className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-[#12151e] hover:bg-[#1a1f2c] border border-[#262c3d] text-white font-semibold text-xs transition active:scale-98 cursor-pointer"
        >
          {copied ? <CheckCheck className="w-4 h-4 text-[#00ff88]" /> : <Copy className="w-4 h-4" />}
          <span>{copied ? (lang === 'bn' ? 'কপি হয়েছে!' : 'Copied!') : (lang === 'bn' ? 'Copy All Sensi' : 'Copy Sensi')}</span>
        </button>

        {/* Test Drag Simulator */}
        <button
          onClick={onOpenSimulator}
          className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-gradient-to-r from-[#ff003c] to-[#990024] hover:opacity-90 text-white font-bold text-xs shadow-md glow-red-sm transition active:scale-98 cursor-pointer"
        >
          <Crosshair className="w-4 h-4" />
          <span>{lang === 'bn' ? 'ড্র্যাগ টেস্ট করুন' : 'Test Drag'}</span>
        </button>
      </div>
    </div>
  );
};
