import React from 'react';
import { X, Trash2, Smartphone, Calendar, ArrowUpRight } from 'lucide-react';
import { Language, SavedSetup, SensiResult } from '../types';
import { playClickSound } from '../utils/audio';

interface SavedVaultProps {
  isOpen: boolean;
  onClose: () => void;
  setups: SavedSetup[];
  onSelectSetup: (result: SensiResult) => void;
  onDeleteSetup: (id: string) => void;
  lang: Language;
}

export const SavedVault: React.FC<SavedVaultProps> = ({
  isOpen,
  onClose,
  setups,
  onSelectSetup,
  onDeleteSetup,
  lang
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#12151e] border border-[#262c3d] rounded-2xl p-5 shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#262c3d]">
          <h3 className="text-base font-bold text-white font-orbitron">
            {lang === 'bn' ? 'সংরক্ষিত সেন্সিটিভিটি ফাইল' : 'Saved Sensi Vault'}
          </h3>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="text-gray-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto py-3 space-y-2.5">
          {setups.length === 0 ? (
            <div className="text-center py-12 text-gray-500 text-xs font-siliguri">
              {lang === 'bn'
                ? 'এখনও কোনো সেন্সিটিভিটি ফাইল সেভ করা হয়নি। নতুন সেন্সি বানিয়ে "Save Setup" বাটনে চাপুন।'
                : 'No saved setups yet. Generate a sensi and tap "Save Setup".'}
            </div>
          ) : (
            setups.map((setup) => (
              <div
                key={setup.id}
                className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d] hover:border-[#ff003c]/60 transition flex items-center justify-between group"
              >
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-sm text-white">
                    <Smartphone className="w-3.5 h-3.5 text-[#ff003c]" />
                    <span>{setup.name}</span>
                  </div>
                  <div className="text-[11px] text-gray-400 mt-0.5">
                    {setup.result.ram} • Gen: {setup.result.general} • DPI: {setup.result.recommendedDpi}
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-gray-500 mt-1">
                    <Calendar className="w-3 h-3" />
                    <span>{setup.savedAt}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      playClickSound();
                      onSelectSetup(setup.result);
                      onClose();
                    }}
                    className="p-2 rounded-lg bg-[#ff003c]/20 hover:bg-[#ff003c] text-[#ff003c] hover:text-white transition"
                    title={lang === 'bn' ? 'লোড করুন' : 'Load Setup'}
                  >
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      playClickSound();
                      onDeleteSetup(setup.id);
                    }}
                    className="p-2 rounded-lg hover:bg-red-500/20 text-gray-500 hover:text-red-400 transition"
                    title={lang === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
