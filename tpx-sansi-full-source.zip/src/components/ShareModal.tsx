import React, { useState } from 'react';
import { X, Copy, Check, Share2, Globe, MessageSquare, ExternalLink } from 'lucide-react';
import { Language } from '../types';
import { playClickSound } from '../utils/audio';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const PUBLIC_APP_URL = 'https://ais-pre-elfthy4r3s6ib2dsh6t525-266410243287.asia-northeast1.run.app';

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, lang }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    playClickSound();
    navigator.clipboard.writeText(PUBLIC_APP_URL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const shareText = encodeURIComponent(
    '🔥 Free Fire VIP 200 Scale Auto Headshot Sensi Generator! আপনার ফোনের ২০০ স্কেলের পারফেক্ট হেডশট সেন্সি নিন এখানে: ' +
      PUBLIC_APP_URL
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#12151e] border border-[#262c3d] rounded-2xl p-5 shadow-2xl flex flex-col glow-red">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#262c3d]">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-[#00ff88]/20 text-[#00ff88]">
              <Globe className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white font-orbitron">
                {lang === 'bn' ? 'পাবলিক লাইভ লিংক' : 'Public Live Link'}
              </h3>
              <p className="text-[11px] text-[#00ff88]">
                {lang === 'bn' ? '● ইন্টারনেট জুড়ে লাইভ ও অ্যাক্টিভ' : '● Live & Public Worldwide'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="text-gray-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="py-4 space-y-3.5">
          <p className="text-xs text-gray-300 font-siliguri leading-relaxed">
            {lang === 'bn'
              ? 'আপনার ওয়েবসাইটটি বর্তমানে গুগল ক্লাউডে সবার জন্য পাবলিক করা আছে! নিচের লিংকটি কপি করে যে কাউকে পাঠান বা সোশ্যাল মিডিয়ায় শেয়ার করুন:'
              : 'Your website is now publicly hosted on Google Cloud! Anyone in the world can access it using the link below:'}
          </p>

          {/* URL Box */}
          <div className="bg-[#090a0f] p-2.5 rounded-xl border border-[#262c3d] flex items-center justify-between gap-2">
            <span className="text-xs text-[#00ff88] font-mono truncate select-all">
              {PUBLIC_APP_URL}
            </span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#ff003c] hover:bg-[#d60032] text-white text-xs font-bold transition shrink-0 active:scale-95"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? (lang === 'bn' ? 'কপি হয়েছে' : 'Copied') : (lang === 'bn' ? 'কপি লিংক' : 'Copy')}</span>
            </button>
          </div>

          {/* Quick Share Buttons */}
          <div className="grid grid-cols-2 gap-2 pt-2">
            <a
              href={`https://api.whatsapp.com/send?text=${shareText}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#25D366]/20 hover:bg-[#25D366]/30 border border-[#25D366]/50 text-[#25D366] text-xs font-semibold transition"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp এ শেয়ার</span>
            </a>

            <a
              href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(PUBLIC_APP_URL)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#1877F2]/20 hover:bg-[#1877F2]/30 border border-[#1877F2]/50 text-[#1877F2] text-xs font-semibold transition"
            >
              <Share2 className="w-4 h-4" />
              <span>Facebook এ শেয়ার</span>
            </a>
          </div>

          {/* Open in new tab button */}
          <a
            href={PUBLIC_APP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#12151e] border border-[#262c3d] hover:border-[#00ff88] text-gray-300 hover:text-white text-xs transition"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'নতুন ট্যাবে ওয়েবসাইটটি খুলুন' : 'Open in New Tab'}</span>
          </a>
        </div>
      </div>
    </div>
  );
};
