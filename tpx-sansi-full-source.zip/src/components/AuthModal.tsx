import React, { useState } from 'react';
import { ShieldCheck, Mail, CheckCircle2, X } from 'lucide-react';
import { Language, UserProfile } from '../types';
import { playClickSound, playGenerateSuccessSound } from '../utils/audio';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (user: UserProfile) => void;
  lang: Language;
}

const PRESET_ACCOUNTS = [
  'rahatyamin9@gmail.com',
  'gamer.vip200@gmail.com',
  'headshot.pro@gmail.com',
  'bd.ff.esports@gmail.com'
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLogin,
  lang
}) => {
  const [customEmail, setCustomEmail] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSelectAccount = (email: string) => {
    playGenerateSuccessSound();
    onLogin({
      email,
      name: email.split('@')[0],
      loginTime: new Date().toLocaleTimeString()
    });
    onClose();
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEmail || !customEmail.includes('@') || !customEmail.includes('.')) {
      setError(
        lang === 'bn'
          ? 'দয়া করে একটি সঠিক জিমেইল এড্রেস দিয়ে প্রবেশ করুন।'
          : 'Please enter a valid Gmail address.'
      );
      return;
    }
    handleSelectAccount(customEmail.trim().toLowerCase());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#12151e] border border-[#262c3d] rounded-2xl p-6 shadow-2xl glow-red">
        {/* Close Button */}
        <button
          onClick={() => {
            playClickSound();
            onClose();
          }}
          className="absolute top-4 right-4 text-gray-400 hover:text-white p-1 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Icon */}
        <div className="text-center mb-5">
          <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-[#ff003c]/15 border border-[#ff003c]/30 flex items-center justify-center text-[#ff003c]">
            <ShieldCheck className="w-9 h-9" />
          </div>
          <h2 className="text-lg font-bold text-white font-siliguri">
            {lang === 'bn' ? 'গুগল দিয়ে লগইন করুন' : 'Sign in with Google'}
          </h2>
          <p className="text-xs text-[#94a3b8] mt-1 px-4 leading-relaxed font-siliguri">
            {lang === 'bn'
              ? 'আপনার ডিভাইস আইডির সাথে VIP Sensi ফাইল কানেক্ট করতে প্রথমে জিমেইল দিয়ে সাইন-ইন করুন।'
              : 'Connect your device ID with the VIP Sensi file by signing in with your Google account.'}
          </p>
        </div>

        {/* Instant 1-Click Google Sign In Button */}
        <div className="space-y-3">
          <button
            onClick={() => handleSelectAccount('rahatyamin9@gmail.com')}
            className="w-full flex items-center justify-center gap-3 bg-white text-gray-800 hover:bg-gray-100 font-semibold py-3 px-4 rounded-xl transition shadow-md active:scale-98"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span className="text-sm">
              {lang === 'bn' ? '১-ক্লিক গুগল সাইন-ইন' : 'One-Click Google Sign In'}
            </span>
          </button>

          <div className="relative my-4 text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[#262c3d]" />
            </div>
            <span className="relative bg-[#12151e] px-2 text-[11px] text-gray-500 uppercase tracking-wider">
              {lang === 'bn' ? 'অথবা আপনার জিমেইল লিখুন' : 'Or enter custom Gmail'}
            </span>
          </div>

          {/* Custom Email Form */}
          <form onSubmit={handleCustomSubmit} className="space-y-3">
            <div className="relative">
              <Mail className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
              <input
                type="email"
                value={customEmail}
                onChange={(e) => {
                  setCustomEmail(e.target.value);
                  setError('');
                }}
                placeholder="yourname@gmail.com"
                className="w-full bg-[#090a0f] border border-[#262c3d] rounded-xl pl-10 pr-3 py-2.5 text-sm text-white focus:outline-none focus:border-[#ff003c] transition"
              />
            </div>

            {error && (
              <p className="text-xs text-[#ff3333] text-center font-siliguri">
                {error}
              </p>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-[#ff003c] hover:bg-[#d60032] text-white font-bold text-sm transition shadow-lg shadow-[#ff003c]/20"
            >
              {lang === 'bn' ? 'লগইন কনফার্ম করুন' : 'Confirm Login'}
            </button>
          </form>

          {/* Quick presets */}
          <div className="pt-2">
            <div className="text-[11px] text-gray-500 mb-1.5 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-[#00ff88]" />
              <span>{lang === 'bn' ? 'দ্রুত টেস্ট একাউন্ট:' : 'Quick Select:'}</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {PRESET_ACCOUNTS.map((acc) => (
                <button
                  key={acc}
                  type="button"
                  onClick={() => handleSelectAccount(acc)}
                  className="text-[10px] px-2 py-1 rounded-md bg-[#090a0f] hover:bg-[#ff003c]/10 text-gray-400 hover:text-white border border-[#262c3d] hover:border-[#ff003c] transition"
                >
                  {acc}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
