import React from 'react';
import { Volume2, VolumeX, Globe, Shield, Sparkles, BookmarkCheck, BookOpen } from 'lucide-react';
import { Language, UserProfile } from '../types';
import { playClickSound } from '../utils/audio';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  user: UserProfile | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  savedCount: number;
  onOpenSaved: () => void;
  onOpenTips: () => void;
  onOpenShare: () => void;
  onOpenPublishGuide: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  lang,
  onToggleLang,
  soundEnabled,
  onToggleSound,
  user,
  onOpenAuth,
  onLogout,
  savedCount,
  onOpenSaved,
  onOpenTips,
  onOpenShare,
  onOpenPublishGuide
}) => {
  return (
    <header className="w-full flex flex-col items-center gap-3 pt-3 pb-2 px-4 z-40">
      {/* Top Domain Badge */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#ff003c]/10 border border-[#ff003c] text-[#ff003c] font-orbitron text-xs sm:text-sm tracking-widest glow-red">
          <Globe className="w-3.5 h-3.5 animate-pulse" />
          <span>WWW.TPXSANSI.COM</span>
        </div>

        {/* Server & Ping Status */}
        <div className="hidden sm:inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#12151e] border border-[#262c3d] text-[11px] text-[#94a3b8]">
          <span className="w-2 h-2 rounded-full bg-[#00ff88] animate-ping" />
          <span className="text-[#00ff88] font-mono">14ms</span>
          <span className="text-gray-500">•</span>
          <span>VIP SERVER ONLINE</span>
        </div>
      </div>

      {/* Control Strip */}
      <div className="w-full max-w-xl flex items-center justify-between bg-[#12151e]/80 backdrop-blur-md border border-[#262c3d] px-3 py-2 rounded-xl text-xs">
        <div className="flex items-center gap-2">
          {user ? (
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-[#ff003c] text-white flex items-center justify-center font-bold text-xs shadow-inner">
                {user.email.charAt(0).toUpperCase()}
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] text-gray-400 max-w-[110px] sm:max-w-[160px] truncate">
                  {user.email}
                </span>
                <span className="text-[9px] text-[#00ff88] font-orbitron flex items-center gap-1">
                  <Shield className="w-2.5 h-2.5" /> VIP ACTIVE
                </span>
              </div>
              <button
                onClick={() => {
                  playClickSound();
                  onLogout();
                }}
                className="ml-1 text-gray-400 hover:text-[#ff003c] p-1 transition-colors"
                title={lang === 'bn' ? 'লগআউট' : 'Logout'}
              >
                ✕
              </button>
            </div>
          ) : (
            <button
              onClick={() => {
                playClickSound();
                onOpenAuth();
              }}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#ff003c]/15 hover:bg-[#ff003c]/25 border border-[#ff003c]/40 text-[#ff003c] font-semibold transition"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'লগইন করুন' : 'Sign In'}</span>
            </button>
          )}
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-2">
          {/* Saved Vault */}
          <button
            onClick={() => {
              playClickSound();
              onOpenSaved();
            }}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[#090a0f] border border-[#262c3d] text-gray-300 hover:border-[#ff003c] transition relative"
            title={lang === 'bn' ? 'সংরক্ষিত সেন্সি' : 'Saved Sensi'}
          >
            <BookmarkCheck className="w-3.5 h-3.5 text-[#ff003c]" />
            <span className="hidden xs:inline">{lang === 'bn' ? 'সেভড' : 'Saved'}</span>
            {savedCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-[#ff003c] text-[10px] font-bold text-white">
                {savedCount}
              </span>
            )}
          </button>

          {/* Public Share Button */}
          <button
            onClick={() => {
              playClickSound();
              onOpenShare();
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#00ff88]/15 hover:bg-[#00ff88]/25 border border-[#00ff88]/50 text-[#00ff88] transition text-[11px] font-bold"
            title={lang === 'bn' ? 'পাবলিক লিংক শেয়ার' : 'Share Public Link'}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#00ff88] animate-ping" />
            <span>{lang === 'bn' ? 'পাবলিক লিংক' : 'Live Link'}</span>
          </button>

          {/* Google & GitHub Guide Button */}
          <button
            onClick={() => {
              playClickSound();
              onOpenPublishGuide();
            }}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[#090a0f] border border-[#262c3d] text-gray-300 hover:border-[#ff003c] transition text-[11px]"
            title={lang === 'bn' ? 'Google সার্চ ও GitHub গাইড' : 'Google SEO & GitHub'}
          >
            <span className="text-[#ff003c]">🔍</span>
            <span className="hidden sm:inline">{lang === 'bn' ? 'গুগল SEO' : 'Google SEO'}</span>
          </button>

          {/* Headshot Tips */}
          <button
            onClick={() => {
              playClickSound();
              onOpenTips();
            }}
            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[#090a0f] border border-[#262c3d] text-gray-300 hover:border-[#00ff88] transition"
            title={lang === 'bn' ? 'হেডশট গাইড' : 'Pro Headshot Tips'}
          >
            <BookOpen className="w-3.5 h-3.5 text-[#00ff88]" />
            <span className="hidden sm:inline">{lang === 'bn' ? 'গাইড' : 'Tips'}</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              onToggleSound();
              playClickSound();
            }}
            className="p-1.5 rounded-lg bg-[#090a0f] border border-[#262c3d] text-gray-400 hover:text-white transition"
            title={soundEnabled ? 'Mute SFX' : 'Unmute SFX'}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-[#00ff88]" /> : <VolumeX className="w-3.5 h-3.5 text-gray-500" />}
          </button>

          {/* Language Switch */}
          <button
            onClick={() => {
              playClickSound();
              onToggleLang();
            }}
            className="px-2 py-1 rounded-lg bg-[#090a0f] border border-[#262c3d] text-gray-300 hover:border-[#ff003c] transition font-orbitron font-bold text-[11px]"
          >
            {lang === 'bn' ? 'EN' : 'বাংলা'}
          </button>
        </div>
      </div>
    </header>
  );
};
