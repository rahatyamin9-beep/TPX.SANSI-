import React from 'react';
import { Smartphone, Cpu, HardDrive, Zap, Crosshair, AlertTriangle } from 'lucide-react';
import { Language, PlaystyleType } from '../types';
import { POPULAR_DEVICES } from '../utils/sensiCalculator';
import { playClickSound } from '../utils/audio';

interface SensiFormProps {
  model: string;
  setModel: (val: string) => void;
  ram: string;
  setRam: (val: string) => void;
  rom: string;
  setRom: (val: string) => void;
  android: string;
  setAndroid: (val: string) => void;
  playstyle: PlaystyleType;
  setPlaystyle: (val: PlaystyleType) => void;
  onGenerate: () => void;
  error: string | null;
  lang: Language;
}

export const SensiForm: React.FC<SensiFormProps> = ({
  model,
  setModel,
  ram,
  setRam,
  rom,
  setRom,
  android,
  setAndroid,
  playstyle,
  setPlaystyle,
  onGenerate,
  error,
  lang
}) => {
  const handleSelectPopular = (item: typeof POPULAR_DEVICES[0]) => {
    playClickSound();
    setModel(item.model);
    setRam(item.ram);
    setRom(item.rom);
    setAndroid(item.android);
  };

  return (
    <div className="space-y-4">
      {/* Quick device suggestions */}
      <div>
        <label className="text-[11px] text-gray-400 font-medium mb-1.5 flex items-center gap-1">
          <Zap className="w-3 h-3 text-[#ff003c]" />
          <span>{lang === 'bn' ? 'জনপ্রিয় ডিভাইস কুইক সিলেক্ট:' : 'Quick Autofill Popular Devices:'}</span>
        </label>
        <div className="flex gap-1.5 overflow-x-auto pb-1.5 no-scrollbar scroll-smooth">
          {POPULAR_DEVICES.slice(0, 6).map((item) => (
            <button
              key={item.model}
              type="button"
              onClick={() => handleSelectPopular(item)}
              className="text-[10px] whitespace-nowrap px-2.5 py-1 rounded-full bg-[#090a0f] border border-[#262c3d] hover:border-[#ff003c] text-gray-300 hover:text-white transition active:scale-95"
            >
              {item.model}
            </button>
          ))}
        </div>
      </div>

      {/* Model Input */}
      <div className="space-y-1">
        <label className="text-xs font-semibold text-[#94a3b8] flex items-center gap-1.5">
          <Smartphone className="w-3.5 h-3.5 text-[#ff003c]" />
          <span>{lang === 'bn' ? 'আপনার ফোনের পুরো মডেলের নাম *' : 'Your Phone Full Model Name *'}</span>
        </label>
        <input
          type="text"
          value={model}
          onChange={(e) => setModel(e.target.value)}
          placeholder={lang === 'bn' ? 'যেমন: INFINIX HOT 50' : 'e.g. INFINIX HOT 50'}
          className="w-full bg-[#090a0f] border border-[#262c3d] focus:border-[#ff003c] focus:ring-1 focus:ring-[#ff003c] rounded-xl px-3.5 py-3 text-sm text-white placeholder-gray-600 outline-none transition"
        />
      </div>

      {/* RAM & ROM Split Row */}
      <div className="grid grid-cols-2 gap-3">
        {/* RAM */}
        <div className="space-y-1">
          <label className="text-xs font-semibold text-[#94a3b8] flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-[#ff003c]" />
            <span>RAM *</span>
          </label>
          <select
            value={ram}
            onChange={(e) => setRam(e.target.value)}
            className="w-full bg-[#090a0f] border border-[#262c3d] focus:border-[#ff003c] rounded-xl px-3 py-3 text-sm text-white outline-none transition cursor-pointer"
          >
            <option value="">{lang === 'bn' ? 'সিলেক্ট করুন' : 'Select RAM'}</option>
            <option value="2GB RAM">2 GB RAM</option>
            <option value="3GB RAM">3 GB RAM</option>
            <option value="4GB RAM">4 GB RAM</option>
            <option value="6GB RAM">6 GB RAM</option>
            <option value="8GB RAM">8 GB RAM</option>
            <option value="12GB RAM">12 GB RAM</option>
            <option value="16GB RAM">16 GB RAM</option>
            <option value="24GB RAM">24 GB RAM</option>
            <option value="32GB RAM">32 GB RAM</option>
          </select>
        </div>

        {/* ROM */}
        <div className="space-y-1">
          <label className="text-xs font-semibold text-[#94a3b8] flex items-center gap-1.5">
            <HardDrive className="w-3.5 h-3.5 text-[#ff003c]" />
            <span>Storage (ROM) *</span>
          </label>
          <select
            value={rom}
            onChange={(e) => setRom(e.target.value)}
            className="w-full bg-[#090a0f] border border-[#262c3d] focus:border-[#ff003c] rounded-xl px-3 py-3 text-sm text-white outline-none transition cursor-pointer"
          >
            <option value="">{lang === 'bn' ? 'সিলেক্ট করুন' : 'Select ROM'}</option>
            <option value="64GB Storage">64 GB Storage</option>
            <option value="128GB Storage">128 GB Storage</option>
            <option value="256GB Storage">256 GB Storage</option>
            <option value="512GB Storage">512 GB Storage</option>
            <option value="1TB Storage">1 TB Storage</option>
          </select>
        </div>
      </div>

      {/* Android Version */}
      <div className="space-y-1">
        <label className="text-xs font-semibold text-[#94a3b8] flex items-center gap-1.5">
          <span className="text-[#00ff88]">🤖</span>
          <span>{lang === 'bn' ? 'Android Version / OS *' : 'Android Version / OS *'}</span>
        </label>
        <input
          type="text"
          value={android}
          onChange={(e) => setAndroid(e.target.value)}
          placeholder={lang === 'bn' ? 'যেমন: Android 13 / Android 14' : 'e.g. Android 13 / Android 14'}
          className="w-full bg-[#090a0f] border border-[#262c3d] focus:border-[#ff003c] focus:ring-1 focus:ring-[#ff003c] rounded-xl px-3.5 py-3 text-sm text-white placeholder-gray-600 outline-none transition"
        />
      </div>

      {/* Weapon Playstyle Calibration */}
      <div className="space-y-1 pt-1">
        <label className="text-xs font-semibold text-[#94a3b8] flex items-center gap-1.5">
          <Crosshair className="w-3.5 h-3.5 text-[#00ff88]" />
          <span>{lang === 'bn' ? 'গান বা খেলার ধরন (অপশনাল ফাইন-টিউন):' : 'Weapon Playstyle Specialty:'}</span>
        </label>
        <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
          {[
            { id: 'all', labelBn: 'সব গান', labelEn: 'All Gun' },
            { id: 'shotgun', labelBn: 'M1887/Shotgun', labelEn: 'Shotgun' },
            { id: 'smg', labelBn: 'MP40/SMG', labelEn: 'SMG Spray' },
            { id: 'ar', labelBn: 'AK/AR Gun', labelEn: 'AR Rifle' },
            { id: 'sniper', labelBn: 'AWM/Sniper', labelEn: 'Sniper' }
          ].map((style) => (
            <button
              key={style.id}
              type="button"
              onClick={() => {
                playClickSound();
                setPlaystyle(style.id as PlaystyleType);
              }}
              className={`py-2 px-1 text-center rounded-lg text-[11px] font-semibold border transition ${
                playstyle === style.id
                  ? 'bg-[#ff003c]/20 border-[#ff003c] text-white shadow-sm shadow-[#ff003c]/30'
                  : 'bg-[#090a0f] border-[#262c3d] text-gray-400 hover:text-white'
              }`}
            >
              {lang === 'bn' ? style.labelBn : style.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="flex items-center justify-center gap-2 text-xs text-[#ff3333] bg-[#ff3333]/10 border border-[#ff3333]/30 p-2.5 rounded-xl font-siliguri animate-shake">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Action Button */}
      <button
        type="button"
        onClick={onGenerate}
        className="w-full mt-3 bg-gradient-to-r from-[#ff003c] via-[#e60036] to-[#b3002a] hover:from-[#ff1a4f] hover:to-[#cc0033] text-white py-3.5 px-4 rounded-xl font-bold font-orbitron tracking-wide text-sm sm:text-base flex items-center justify-center gap-2 glow-red transition-all transform active:scale-98 cursor-pointer"
      >
        <Zap className="w-4 h-4 fill-white" />
        <span>{lang === 'bn' ? 'Generate 200 Scale Sensi' : 'Generate 200 Scale Sensi'}</span>
      </button>
    </div>
  );
};
