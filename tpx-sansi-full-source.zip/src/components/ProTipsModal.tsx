import React from 'react';
import { X, Flame, Crosshair, Sparkles } from 'lucide-react';
import { Language } from '../types';
import { playClickSound } from '../utils/audio';

interface ProTipsModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const ProTipsModal: React.FC<ProTipsModalProps> = ({ isOpen, onClose, lang }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#12151e] border border-[#262c3d] rounded-2xl p-5 shadow-2xl flex flex-col max-h-[85vh]">
        <div className="flex items-center justify-between pb-3 border-b border-[#262c3d]">
          <h3 className="text-sm sm:text-base font-bold text-white font-orbitron flex items-center gap-2">
            <Flame className="w-4 h-4 text-[#ff003c]" />
            <span>{lang === 'bn' ? 'VIP অটো হেডশট সিক্রেট ট্রিকস' : 'VIP Auto Headshot Secrets'}</span>
          </h3>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="text-gray-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-3 space-y-3 text-xs leading-relaxed font-siliguri text-gray-300">
          {/* Tip 1: J-Drag */}
          <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
            <h4 className="text-white font-bold flex items-center gap-1.5 mb-1 text-xs">
              <Crosshair className="w-3.5 h-3.5 text-[#ff003c]" />
              <span>{lang === 'bn' ? '১. J-শেপ ড্র্যাগ (শর্ট রেঞ্জের জন্য)' : '1. J-Shape Drag (Close Range)'}</span>
            </h4>
            <p className="text-[11px] text-gray-400">
              {lang === 'bn'
                ? 'শত্রু যখন কাছে থাকে, ফায়ার বাটন হালকা নিচে টেনে দ্রুত ইংরেজি ‘J’ অক্ষরের মতো উপরের দিকে সুইপ করুন। এতে এম কখনোই বুকে লক হবে না।'
                : 'When the enemy is close, pull the fire button slightly down and flick up in an English "J" arc to break chest aim-lock.'}
            </p>
          </div>

          {/* Tip 2: Straight Drag */}
          <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
            <h4 className="text-white font-bold flex items-center gap-1.5 mb-1 text-xs">
              <Sparkles className="w-3.5 h-3.5 text-[#00ff88]" />
              <span>{lang === 'bn' ? '২. সোজা সোয়াইপ (মিড ও লং রেঞ্জ)' : '2. Straight Swipe (Mid & Long Range)'}</span>
            </h4>
            <p className="text-[11px] text-gray-400">
              {lang === 'bn'
                ? 'দূরবর্তী শত্রুর ক্ষেত্রে ফায়ার বাটন আলতোভাবে এবং স্থির গতিতে সরাসরি আকাশের দিকে টানুন।'
                : 'For mid to long range targets, swipe the fire button smoothly and steadily straight upward toward the sky.'}
            </p>
          </div>

          {/* Tip 3: Button Size */}
          <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
            <h4 className="text-white font-bold flex items-center gap-1.5 mb-1 text-xs">
              <span className="text-[#ff003c]">🎯</span>
              <span>{lang === 'bn' ? '৩. ফায়ার বাটনের পজিশন সিক্রেট' : '3. Button Positioning Secret'}</span>
            </h4>
            <p className="text-[11px] text-gray-400">
              {lang === 'bn'
                ? 'বাটন যত স্ক্রিনের নিচে রাখবেন, আপনার আঙুল উপরে তোলার (Drag Lift Space) জায়গা তত বাড়বে। বাটনের সাইজ ৪৫% এর আশেপাশে রাখা সবচেয়ে আইডিয়াল।'
                : 'Placing the fire button lower on the screen grants you maximum vertical drag travel. Keeping size around 42-46% prevents misclicks.'}
            </p>
          </div>

          {/* Tip 4: Finger Sleeve & Powder */}
          <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
            <h4 className="text-white font-bold flex items-center gap-1.5 mb-1 text-xs">
              <span className="text-yellow-400">⚡</span>
              <span>{lang === 'bn' ? '৪. স্ক্রিন ফ্রিকশন ও টাচ স্মুথনেস' : '4. Screen Friction & Touch Sampling'}</span>
            </h4>
            <p className="text-[11px] text-gray-400">
              {lang === 'bn'
                ? 'ঘাম বা তেলের কারণে ড্র্যাগ আটকে গেলে সামান্য বেবি পাউডার বা ফিঙ্গার স্লিভ (Finger Sleeve) ব্যবহার করুন। এর ফলে হেডশটের একিউরেসি দ্বিগুণ হবে।'
                : 'Eliminate screen friction using gaming finger sleeves or light powder for zero resistance during high-speed flick shots.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
