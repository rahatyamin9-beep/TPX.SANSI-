import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('TPX SANSI Error:', error, errorInfo);
  }

  public handleReload = () => {
    try {
      localStorage.removeItem('tpx_saved_setups');
    } catch {
      // ignore
    }
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#090a0f] text-[#f1f5f9] flex flex-col items-center justify-center p-6 text-center font-sans">
          <div className="max-w-md w-full bg-[#12151e] border border-[#ff003c]/40 rounded-2xl p-6 shadow-2xl">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#ff003c]/15 border border-[#ff003c]/30 flex items-center justify-center text-[#ff003c]">
              <AlertTriangle className="w-8 h-8" />
            </div>
            <h2 className="text-xl font-bold font-orbitron text-white mb-2">
              TPX SANSI VIP
            </h2>
            <p className="text-xs text-gray-400 mb-6 font-siliguri leading-relaxed">
              অ্যাপটি লোড করতে সামান্য সমস্যা হয়েছিল। নিচের বাটনে চাপ দিয়ে অ্যাপটি আবার ফ্রেশভাবে রিলোড করুন।
            </p>
            <button
              onClick={this.handleReload}
              className="w-full py-3 px-4 rounded-xl bg-[#ff003c] hover:bg-[#d60032] text-white font-bold text-sm flex items-center justify-center gap-2 transition"
            >
              <RefreshCw className="w-4 h-4" />
              <span>রিলোড করুন (Reload App)</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
