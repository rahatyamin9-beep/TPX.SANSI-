import React from 'react';
import { X, AlertCircle, ShieldAlert, CheckCircle } from 'lucide-react';
import { Language } from '../types';
import { playClickSound } from '../utils/audio';

interface DpiModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const DpiModal: React.FC<DpiModalProps> = ({ isOpen, onClose, lang }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#12151e] border border-[#262c3d] rounded-2xl p-5 shadow-2xl flex flex-col max-h-[85vh]">
        <div className="flex items-center justify-between pb-3 border-b border-[#262c3d]">
          <h3 className="text-sm sm:text-base font-bold text-white font-orbitron flex items-center gap-2">
            <span className="text-[#00ff88]">⚙️</span>
            <span>{lang === 'bn' ? 'নিরাপদে DPI সেট করার নিয়ম' : 'Safe DPI Guide'}</span>
          </h3>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="text-gray-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-3 space-y-3 text-xs leading-relaxed text-gray-300 font-siliguri">
          {/* Step 1 */}
          <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
            <div className="font-bold text-white mb-1 flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-[#ff003c] text-white flex items-center justify-center text-[10px]">1</span>
              <span>{lang === 'bn' ? 'ডেভেলপার অপশন অন করুন' : 'Enable Developer Options'}</span>
            </div>
            <p className="text-gray-400 text-[11px]">
              {lang === 'bn'
                ? 'ফোনের Settings > About Phone এ যান। সেখানে "Build Number" এর উপর টানা ৭ বার ক্লিক করুন।'
                : 'Go to Settings > About Phone. Tap "Build Number" rapidly 7 times until developer mode is unlocked.'}
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
            <div className="font-bold text-white mb-1 flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-[#ff003c] text-white flex items-center justify-center text-[10px]">2</span>
              <span>{lang === 'bn' ? 'Smallest Width খুঁজে বের করুন' : 'Find Smallest Width'}</span>
            </div>
            <p className="text-gray-400 text-[11px]">
              {lang === 'bn'
                ? 'System > Developer Options এ যান। স্ক্রল করে নিচে "Smallest Width" বা "Minimum Width" অপশনে যান।'
                : 'Navigate to System > Developer Options. Scroll down to find "Smallest Width" or "Minimum Width".'}
            </p>
          </div>

          {/* Warning */}
          <div className="bg-[#ff003c]/10 border border-[#ff003c]/40 p-3 rounded-xl flex items-start gap-2 text-[#ff99aa]">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-[#ff003c]" />
            <div className="text-[11px]">
              <strong className="block text-white mb-0.5">
                {lang === 'bn' ? 'সতর্কতা (DPI Limit):' : 'Important DPI Safety Rule:'}
              </strong>
              {lang === 'bn'
                ? 'কখনোই DPI ৫০০ এর উপরে দেবেন না! আপনার ডিফল্ট DPI (যেমন ৩৬০ বা ৩৯২) মনে রাখুন, যাতে প্রয়োজনে আগের মানে ফিরিয়ে আনা যায়।'
                : 'Never exceed 500 DPI on budget devices. Always take note of your phone default DPI (usually 360 or 392).'}
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
            <div className="font-bold text-white mb-1 flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-[#00ff88]" />
              <span>{lang === 'bn' ? 'পয়েন্টার স্পিড ম্যাক্সিমাম রাখুন' : 'Set Pointer Speed to Max'}</span>
            </div>
            <p className="text-gray-400 text-[11px]">
              {lang === 'bn'
                ? 'Settings > Language & Input > Pointer Speed সম্পূর্ণ ডানে নিয়ে রাখুন।'
                : 'Go to Settings > Language & Input > Pointer Speed and slide it to maximum.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
