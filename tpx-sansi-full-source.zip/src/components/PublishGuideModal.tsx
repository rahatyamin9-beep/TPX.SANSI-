import React, { useState } from 'react';
import { X, Globe, Check, Copy, ExternalLink, ShieldCheck, Terminal, Search, Download, FolderArchive, ArrowRight } from 'lucide-react';
import { Language } from '../types';
import { playClickSound } from '../utils/audio';

interface PublishGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const PublishGuideModal: React.FC<PublishGuideModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  const [activeTab, setActiveTab] = useState<'download' | 'github' | 'google' | 'whiteScreen'>('download');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isOpen) return null;

  const copyCommand = (cmd: string, idx: number) => {
    playClickSound();
    navigator.clipboard.writeText(cmd);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2500);
  };

  const gitCommands = [
    'git init',
    'git add .',
    'git commit -m "Deploy TPX SANSI VIP to GitHub Pages"',
    'git branch -M main',
    'git remote add origin https://github.com/YOUR_USERNAME/tpx-sansi.git',
    'git push -u origin main'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-[#12151e] border border-[#262c3d] rounded-2xl p-5 sm:p-6 shadow-2xl flex flex-col max-h-[92vh] glow-red">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#262c3d]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#00ff88]/15 border border-[#00ff88]/40 flex items-center justify-center text-[#00ff88]">
              <Download className="w-4 h-4 animate-bounce" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white font-orbitron">
                {lang === 'bn' ? 'GitHub এ ফাইল আপলোড ও লাইভ গাইড' : 'Download Files & GitHub Publish'}
              </h3>
              <p className="text-[11px] text-[#00ff88]">
                {lang === 'bn' ? 'ফাইল ডাউনলোড করুন এবং GitHub এ লাইভ করুন' : 'Download ZIP files & deploy live to GitHub'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="text-gray-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-[#262c3d] my-3 overflow-x-auto no-scrollbar">
          <button
            onClick={() => {
              playClickSound();
              setActiveTab('download');
            }}
            className={`py-2 px-3 text-xs font-bold font-siliguri flex items-center justify-center gap-1.5 border-b-2 transition shrink-0 ${
              activeTab === 'download'
                ? 'border-[#00ff88] text-white bg-[#00ff88]/10'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <FolderArchive className="w-3.5 h-3.5 text-[#00ff88]" />
            <span>{lang === 'bn' ? '১. ফাইল ডাউনলোড (ZIP)' : '1. Download ZIP'}</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              setActiveTab('github');
            }}
            className={`py-2 px-3 text-xs font-bold font-siliguri flex items-center justify-center gap-1.5 border-b-2 transition shrink-0 ${
              activeTab === 'github'
                ? 'border-[#ff003c] text-white bg-[#ff003c]/10'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-[#ff003c]" />
            <span>{lang === 'bn' ? '২. GitHub এ আপলোড' : '2. GitHub Upload'}</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              setActiveTab('google');
            }}
            className={`py-2 px-3 text-xs font-bold font-siliguri flex items-center justify-center gap-1.5 border-b-2 transition shrink-0 ${
              activeTab === 'google'
                ? 'border-[#38bdf8] text-white bg-[#38bdf8]/10'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <Search className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span>{lang === 'bn' ? '৩. গুগল সার্চে আনা' : '3. Google SEO'}</span>
          </button>

          <button
            onClick={() => {
              playClickSound();
              setActiveTab('whiteScreen');
            }}
            className={`py-2 px-3 text-xs font-bold font-siliguri flex items-center justify-center gap-1.5 border-b-2 transition shrink-0 ${
              activeTab === 'whiteScreen'
                ? 'border-yellow-400 text-white bg-yellow-400/10'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-yellow-400" />
            <span>{lang === 'bn' ? 'সাদা স্ক্রিন ফিক্স' : 'Fix White Screen'}</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto space-y-3 py-1 pr-1 text-xs text-gray-300 font-siliguri leading-relaxed">
          {activeTab === 'download' && (
            <div className="space-y-3">
              {/* Ready to Publish Static Site */}
              <div className="bg-[#090a0f] p-3.5 rounded-xl border border-[#00ff88]/40 hover:border-[#00ff88] transition">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h4 className="text-white font-bold text-sm flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#00ff88] animate-ping" />
                      <span>{lang === 'bn' ? 'রেডি ওয়েবসাইট ফাইল (GitHub Web Drag & Drop)' : 'Ready Website Files (For GitHub Drag & Drop)'}</span>
                    </h4>
                    <p className="text-[11px] text-gray-400 mt-0.5">
                      {lang === 'bn'
                        ? 'এটি আনজিপ করে ভেতরের ফাইলগুলো সরাসরি GitHub-এ আপলোড করলেই সাইট অনলাইনে চালু হয়ে যাবে।'
                        : 'Unzip and drag & drop these files directly into GitHub repository.'}
                    </p>
                  </div>
                </div>

                <a
                  href="./tpx-sansi-website.zip"
                  download="tpx-sansi-website.zip"
                  onClick={() => playClickSound()}
                  className="w-full mt-2 py-2.5 px-3 rounded-lg bg-[#00ff88] hover:bg-[#00cc6d] text-black font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-[#00ff88]/20 transition active:scale-98 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>{lang === 'bn' ? 'tpx-sansi-website.zip ডাউনলোড করুন' : 'Download tpx-sansi-website.zip'}</span>
                </a>
              </div>

              {/* Full Source Code */}
              <div className="bg-[#090a0f] p-3.5 rounded-xl border border-[#262c3d]">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h4 className="text-white font-bold text-xs flex items-center gap-1.5">
                      <FolderArchive className="w-3.5 h-3.5 text-[#ff003c]" />
                      <span>{lang === 'bn' ? 'সম্পূর্ণ সোর্স কোড (Full Source Code + GitHub Actions)' : 'Full Source Code (With Workflows)'}</span>
                    </h4>
                    <p className="text-[11px] text-gray-400 mt-0.5">
                      {lang === 'bn'
                        ? 'React, Vite, Tailwind এবং স্বয়ংক্রিয় GitHub Actions ডেপ্লয়মেন্ট স্ক্রিপ্টসহ পুরো সোর্স কোড।'
                        : 'Includes React, Vite, Tailwind and pre-configured GitHub Actions CI/CD.'}
                    </p>
                  </div>
                </div>

                <a
                  href="./tpx-sansi-full-source.zip"
                  download="tpx-sansi-full-source.zip"
                  onClick={() => playClickSound()}
                  className="w-full mt-2 py-2 px-3 rounded-lg bg-[#12151e] hover:bg-[#1a1f2c] border border-[#262c3d] hover:border-[#ff003c] text-white font-semibold text-xs flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-[#ff003c]" />
                  <span>{lang === 'bn' ? 'tpx-sansi-full-source.zip ডাউনলোড করুন' : 'Download Full Source ZIP'}</span>
                </a>
              </div>

              {/* Next step hint */}
              <div className="p-2.5 rounded-xl bg-[#ff003c]/10 border border-[#ff003c]/30 flex items-center justify-between text-[11px] text-gray-300">
                <span>ফাইল ডাউনলোড করেছেন? এবার ২য় ট্যাবে গিয়ে GitHub এ আপলোড করার নিয়ম দেখুন:</span>
                <button
                  onClick={() => {
                    playClickSound();
                    setActiveTab('github');
                  }}
                  className="px-2.5 py-1 rounded-md bg-[#ff003c] hover:bg-[#d60032] text-white font-bold text-[10px] shrink-0 ml-2"
                >
                  পরবর্তী ধাপ ➔
                </button>
              </div>
            </div>
          )}

          {activeTab === 'github' && (
            <div className="space-y-3">
              {/* Method A: Web Drag & Drop (Easiest) */}
              <div className="bg-[#090a0f] p-3 rounded-xl border border-[#00ff88]/40">
                <div className="font-bold text-white flex items-center gap-1.5 mb-1 text-xs">
                  <span className="w-5 h-5 rounded-full bg-[#00ff88] text-black font-bold flex items-center justify-center text-[10px]">A</span>
                  <span>সহজ উপায়: ব্রাউজার দিয়ে GitHub এ আপলোড (No Terminal)</span>
                </div>
                <ol className="list-decimal list-inside text-[11px] text-gray-400 space-y-1.5 mt-1.5">
                  <li>
                    ডাউনলোড করা <code className="text-[#00ff88] font-mono">tpx-sansi-website.zip</code> ফাইলটি আনজিপ (Extract) করুন।
                  </li>
                  <li>
                    <a
                      href="https://github.com/new"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#00ff88] hover:underline inline-flex items-center gap-1"
                    >
                      github.com/new <ExternalLink className="w-3 h-3" />
                    </a>
                    -এ গিয়ে একটি রিপোজিটরি তৈরি করুন (যেমন: <code className="text-white">tpx-sansi</code>)।
                  </li>
                  <li>
                    GitHub পেজে থাকা <strong>"uploading an existing file"</strong> লিংকে ক্লিক করুন।
                  </li>
                  <li>
                    আনজিপ করা ফোল্ডারের ফাইলগুলো (<code className="text-white">index.html</code>, <code className="text-white">assets/</code> ইত্যাদি) ড্র্যাগ করে ড্রপ বক্সে ছেড়ে দিন এবং <strong>"Commit changes"</strong> চাপুন।
                  </li>
                  <li>
                    GitHub রিপোজিটরির <strong>Settings &gt; Pages</strong> এ যান। <strong>Branch: main</strong> এবং <strong>/ (root)</strong> সিলেক্ট করে <strong>Save</strong> চাপুন।
                  </li>
                </ol>
                <div className="mt-2 text-[10px] text-[#00ff88] font-semibold">
                  ✓ ১ মিনিটের মধ্যে আপনার ওয়েবসাইট ফ্রি লাইভ হয়ে যাবে!
                </div>
              </div>

              {/* Method B: Git Command Line */}
              <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
                <div className="font-bold text-white flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-[#ff003c] text-white font-bold flex items-center justify-center text-[10px]">B</span>
                    <span>কমান্ড লাইনে পুশ করার নিয়ম:</span>
                  </div>
                  <button
                    onClick={() => copyCommand(gitCommands.join('\n'), 99)}
                    className="text-[10px] text-[#00ff88] hover:underline flex items-center gap-1"
                  >
                    {copiedIndex === 99 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIndex === 99 ? 'কপি হয়েছে' : 'সব কমান্ড কপি'}</span>
                  </button>
                </div>
                <div className="bg-black/70 p-2.5 rounded-lg border border-gray-800 font-mono text-[10px] text-gray-300 space-y-1 overflow-x-auto">
                  {gitCommands.map((cmd) => (
                    <div key={cmd}>
                      <span>{cmd}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'google' && (
            <div className="space-y-3">
              <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
                <div className="font-bold text-white flex items-center gap-2 mb-1">
                  <span className="w-5 h-5 rounded-full bg-[#38bdf8] text-black font-bold flex items-center justify-center text-[10px]">1</span>
                  <span>সাইটম্যাপ ও SEO রেডি করা হয়েছে</span>
                </div>
                <p className="text-[11px] text-gray-400">
                  আপনার ওয়েবসাইটে <strong>Schema.org JSON-LD</strong>, <strong>robots.txt</strong>, এবং <strong>sitemap.xml</strong> স্বয়ংক্রিয়ভাবে তৈরি করে দেওয়া হয়েছে।
                </p>
              </div>

              <div className="bg-[#090a0f] p-3 rounded-xl border border-[#262c3d]">
                <div className="font-bold text-white flex items-center gap-2 mb-1">
                  <span className="w-5 h-5 rounded-full bg-[#38bdf8] text-black font-bold flex items-center justify-center text-[10px]">2</span>
                  <span>Google Search Console এ সাবমিট করার নিয়ম:</span>
                </div>
                <ol className="list-decimal list-inside text-[11px] text-gray-400 space-y-1.5 mt-1.5">
                  <li>
                    <a
                      href="https://search.google.com/search-console"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#38bdf8] hover:underline inline-flex items-center gap-1"
                    >
                      Google Search Console <ExternalLink className="w-3 h-3" />
                    </a>
                    -এ আপনার জিমেইল দিয়ে লগইন করুন।
                  </li>
                  <li>
                    <strong>"Add Property"</strong>-তে ক্লিক করে আপনার GitHub Pages সাইটের URL দিন।
                  </li>
                  <li>
                    বাম পাশের মেন্যু থেকে <strong>"Sitemaps"</strong> অপশনে যান।
                  </li>
                  <li>
                    খালি বক্সে লিখুন: <code className="text-[#00ff88] font-mono bg-black/50 px-1 py-0.5 rounded">sitemap.xml</code> এবং <strong>Submit</strong> চাপুন।
                  </li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'whiteScreen' && (
            <div className="space-y-3">
              <div className="bg-[#090a0f] p-3 rounded-xl border border-yellow-400/40">
                <div className="font-bold text-white flex items-center gap-1.5 mb-1 text-xs">
                  <span className="text-yellow-400">⚡</span>
                  <span>সাদা স্ক্রিনের স্থায়ী সমাধান নিশ্চিত করা হয়েছে</span>
                </div>
                <p className="text-[11px] text-gray-400">
                  <code className="text-white">base: './'</code> কনফিগারেশনের কারণে আপনি এখন এই ফাইলগুলো GitHub Pages, Vercel, Netlify বা Hostinger যেখানেই আপলোড করবেন, সাথে সাথে পারফেক্টলি চালু হবে; কোনো 404 ফাইল এরর আসবে না।
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#262c3d] flex justify-between items-center">
          <a
            href="./tpx-sansi-website.zip"
            download="tpx-sansi-website.zip"
            onClick={() => playClickSound()}
            className="flex items-center gap-1.5 text-xs text-[#00ff88] hover:underline font-bold"
          >
            <Download className="w-3.5 h-3.5" />
            <span>সরাসরি ZIP ডাউনলোড</span>
          </a>

          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-[#ff003c] hover:bg-[#d60032] text-white text-xs font-bold transition"
          >
            {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
