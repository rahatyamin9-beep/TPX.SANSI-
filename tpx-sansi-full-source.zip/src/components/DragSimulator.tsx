import React, { useState, useRef } from 'react';
import { X, Target, Flame, RotateCcw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language, SensiResult } from '../types';
import { playClickSound, playHeadshotSound } from '../utils/audio';

interface DragSimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  result: SensiResult | null;
  lang: Language;
}

export const DragSimulator: React.FC<DragSimulatorProps> = ({
  isOpen,
  onClose,
  result,
  lang
}) => {
  const [startY, setStartY] = useState<number | null>(null);
  const [startTime, setStartTime] = useState<number>(0);
  const [currentY, setCurrentY] = useState<number | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [feedback, setFeedback] = useState<{
    damage: number;
    isHeadshot: boolean;
    text: string;
    speed: number;
  } | null>(null);
  const [score, setScore] = useState({ hits: 0, headshots: 0 });

  const containerRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handlePointerDown = (e: React.PointerEvent) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    setStartY(e.clientY);
    setCurrentY(e.clientY);
    setStartTime(performance.now());
    setIsDragging(true);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setCurrentY(e.clientY);
  };

  const handlePointerUp = () => {
    if (!isDragging || startY === null || currentY === null) {
      setIsDragging(false);
      return;
    }

    const duration = Math.max(20, performance.now() - startTime);
    const deltaY = startY - currentY; // upward distance (positive)
    const speed = (deltaY / duration) * 100; // px per 100ms

    // Ideal drag threshold based on 200 scale general sensi
    const general = result?.general || 195;
    // higher sensitivity requires less drag force
    const targetMinSpeed = Math.max(30, 140 - (general * 0.45));
    const targetMaxSpeed = targetMinSpeed + 75;

    let isHeadshot = false;
    let damage = 25;
    let text = '';

    if (deltaY < 20) {
      text = lang === 'bn' ? 'ড্র্যাগ হয়নি! বাটন উপরে টানুন' : 'No Drag! Swipe button UP';
      damage = 0;
    } else if (speed < targetMinSpeed) {
      // Too slow: body shot
      damage = Math.floor(Math.random() * 8) + 24;
      text = lang === 'bn' ? 'হোয়াইট ড্যামেজ (বুকে লক)! আরেকটু জোরে ড্র্যাগ করুন' : 'Body Shot! Drag faster!';
    } else if (speed > targetMaxSpeed + 60) {
      // Overshot over head
      damage = 0;
      text = lang === 'bn' ? 'মাথার উপর দিয়ে গুলি গেছে! ড্র্যাগ বেশি জোড়ে হয়েছে' : 'Over the head! Drag with smoother control';
    } else {
      // Perfect Headshot!
      isHeadshot = true;
      damage = Math.floor(Math.random() * 40) + 195;
      text = lang === 'bn' ? '💥 পিওর রেড হেডশট! পারফেক্ট ২-ট্যাপ টাইমিং' : '💥 PURE RED HEADSHOT! Perfect drag timing!';
      playHeadshotSound();
      confetti({
        particleCount: 45,
        spread: 60,
        origin: { y: 0.45 },
        colors: ['#ff003c', '#ff5500', '#ffff00']
      });
    }

    setFeedback({
      damage,
      isHeadshot,
      text,
      speed: Math.round(speed)
    });

    setScore((prev) => ({
      hits: prev.hits + (damage > 0 ? 1 : 0),
      headshots: prev.headshots + (isHeadshot ? 1 : 0)
    }));

    setIsDragging(false);
    setStartY(null);
    setCurrentY(null);
  };

  const resetStats = () => {
    playClickSound();
    setScore({ hits: 0, headshots: 0 });
    setFeedback(null);
  };

  const headshotPercentage = score.hits > 0 ? Math.round((score.headshots / score.hits) * 100) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#12151e] border border-[#262c3d] rounded-2xl p-5 shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#262c3d]">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-[#ff003c]/20 text-[#ff003c]">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white font-orbitron">
                FF DRAG SENSITIVITY TESTER
              </h3>
              <p className="text-[11px] text-gray-400">
                {lang === 'bn' ? '২০০ স্কেলের ড্র্যাগ রেসপন্স টেস্ট করুন' : 'Test drag response on 200 scale'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              playClickSound();
              onClose();
            }}
            className="text-gray-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Score Board */}
        <div className="grid grid-cols-3 gap-2 my-3 p-2 rounded-xl bg-[#090a0f] border border-[#262c3d] text-center text-xs">
          <div>
            <span className="text-[10px] text-gray-400 block">{lang === 'bn' ? 'মোট শট' : 'Shots'}</span>
            <span className="font-orbitron font-bold text-white">{score.hits}</span>
          </div>
          <div className="border-x border-[#262c3d]">
            <span className="text-[10px] text-gray-400 block">{lang === 'bn' ? 'হেডশট' : 'Headshots'}</span>
            <span className="font-orbitron font-bold text-[#ff003c]">{score.headshots}</span>
          </div>
          <div>
            <span className="text-[10px] text-gray-400 block">{lang === 'bn' ? 'হেডশট রেট' : 'Headshot %'}</span>
            <span className="font-orbitron font-bold text-[#00ff88]">{headshotPercentage}%</span>
          </div>
        </div>

        {/* Practice Arena */}
        <div
          ref={containerRef}
          className="relative flex-1 min-h-[280px] bg-[#090a0f] rounded-xl border border-[#262c3d] overflow-hidden flex flex-col items-center justify-between p-4 select-none touch-none"
        >
          {/* Target Enemy Silhouette */}
          <div className="relative mt-2 flex flex-col items-center">
            {/* Floating Damage Indicator */}
            {feedback && (
              <div
                className={`absolute -top-7 animate-bounce font-orbitron font-black text-xl px-2 py-0.5 rounded ${
                  feedback.isHeadshot
                    ? 'text-[#ff003c] drop-shadow-[0_0_10px_rgba(255,0,60,0.8)]'
                    : 'text-white'
                }`}
              >
                {feedback.damage > 0 ? feedback.damage : 'MISS'}
              </div>
            )}

            {/* Target Head & Body Graphic */}
            <div className="relative flex flex-col items-center">
              {/* Head */}
              <div
                className={`w-12 h-12 rounded-full border-2 transition-all flex items-center justify-center ${
                  feedback?.isHeadshot
                    ? 'bg-[#ff003c]/40 border-[#ff003c] scale-110 shadow-[0_0_20px_#ff003c]'
                    : 'bg-[#1e2333] border-gray-600'
                }`}
              >
                <Target className="w-6 h-6 text-gray-400" />
              </div>
              {/* Body */}
              <div className="w-16 h-20 mt-1 rounded-t-xl bg-[#1a1f2e] border border-gray-700 flex items-center justify-center text-[10px] text-gray-500 font-mono">
                CHEST
              </div>
            </div>
          </div>

          {/* Drag Feedback Message */}
          <div className="text-center px-2 min-h-[32px] flex items-center justify-center">
            {feedback ? (
              <p
                className={`text-xs font-semibold ${
                  feedback.isHeadshot ? 'text-[#00ff88]' : 'text-gray-300'
                }`}
              >
                {feedback.text}
              </p>
            ) : (
              <p className="text-xs text-gray-500 animate-pulse font-siliguri">
                {lang === 'bn'
                  ? '👇 নিচের লাল বাটনটি ধরে সোজা উপরে সুইপ (ড্র্যাগ) করুন'
                  : '👇 Tap and swipe the fire button upward to practice'}
              </p>
            )}
          </div>

          {/* Interactive Fire Button */}
          <div className="w-full flex justify-center pb-2">
            <div
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerUp}
              style={{
                width: `${Math.max(50, Math.min(80, (result?.fireButtonSize || 45) * 1.3))}px`,
                height: `${Math.max(50, Math.min(80, (result?.fireButtonSize || 45) * 1.3))}px`
              }}
              className={`rounded-full bg-gradient-to-t from-[#ff003c] to-[#ff3b69] border-2 border-white/60 flex items-center justify-center cursor-pointer shadow-lg shadow-[#ff003c]/50 active:scale-95 transition-transform ${
                isDragging ? 'ring-4 ring-[#00ff88]' : ''
              }`}
            >
              <Flame className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        {/* Footer controls */}
        <div className="flex items-center justify-between pt-3 text-xs">
          <button
            onClick={resetStats}
            className="flex items-center gap-1 text-gray-400 hover:text-white transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{lang === 'bn' ? 'রিসেট স্কোর' : 'Reset'}</span>
          </button>
          <div className="text-[11px] text-gray-400">
            {lang === 'bn'
              ? 'টিপস: দ্রুত সোজা ড্র্যাগে ১০০% রেড নাম্বার পাবেন'
              : 'Tip: Fast straight upward drag locks to head'}
          </div>
        </div>
      </div>
    </div>
  );
};
