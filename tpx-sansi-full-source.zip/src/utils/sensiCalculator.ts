import { PlaystyleType, SensiResult } from '../types';

export const POPULAR_DEVICES = [
  { model: 'INFINIX HOT 50', ram: '8GB RAM', rom: '256GB Storage', android: 'Android 14' },
  { model: 'REDMI NOTE 13 PRO', ram: '8GB RAM', rom: '256GB Storage', android: 'Android 14' },
  { model: 'TECNO POVA 6 NEO', ram: '8GB RAM', rom: '128GB Storage', android: 'Android 14' },
  { model: 'POCO X6 PRO 5G', ram: '12GB RAM', rom: '512GB Storage', android: 'Android 14' },
  { model: 'SAMSUNG GALAXY A54', ram: '8GB RAM', rom: '128GB Storage', android: 'Android 13' },
  { model: 'REALME 12 PLUS', ram: '8GB RAM', rom: '256GB Storage', android: 'Android 14' },
  { model: 'VIVO V30 LITE', ram: '8GB RAM', rom: '256GB Storage', android: 'Android 14' },
  { model: 'ONEPLUS NORD CE 4', ram: '8GB RAM', rom: '256GB Storage', android: 'Android 14' },
  { model: 'INFINIX HOT 30', ram: '4GB RAM', rom: '128GB Storage', android: 'Android 13' },
  { model: 'REDMI 10C / 9A', ram: '3GB RAM', rom: '64GB Storage', android: 'Android 12' }
];

export function calculateSensi(
  model: string,
  ram: string,
  rom: string,
  android: string,
  playstyle: PlaystyleType = 'all'
): SensiResult {
  let general = 195;
  let redDot = 188;
  let scope2 = 182;
  let scope4 = 175;
  let sniperScope = 145;
  let freeLook = 160;
  let optDpi = 411;
  let btnSize = 45;
  let headshotRate = 92;

  // Base RAM tier logic
  if (ram === '2GB RAM' || ram === '3GB RAM') {
    general = 200;
    redDot = 198;
    scope2 = 192;
    scope4 = 188;
    sniperScope = 165;
    freeLook = 180;
    optDpi = 460;
    btnSize = 42;
    headshotRate = 89;
  } else if (ram === '4GB RAM' || ram === '6GB RAM') {
    general = 196;
    redDot = 190;
    scope2 = 185;
    scope4 = 180;
    sniperScope = 152;
    freeLook = 170;
    optDpi = 420;
    btnSize = 45;
    headshotRate = 94;
  } else {
    // 8GB, 12GB, 16GB, 24GB, 32GB
    general = 188;
    redDot = 182;
    scope2 = 178;
    scope4 = 172;
    sniperScope = 140;
    freeLook = 155;
    optDpi = 390;
    btnSize = 48;
    headshotRate = 96;
  }

  // Model-specific touch sampling heuristics
  const modelUpper = model.toUpperCase();
  if (modelUpper.includes('IPHONE') || modelUpper.includes('ROG') || modelUpper.includes('BLACK SHARK')) {
    general = Math.min(200, general - 8);
    redDot = Math.min(200, redDot - 6);
    optDpi = 411; // iPhones don't have DPI setting, but display standard
    btnSize = 44;
    headshotRate = 98;
  } else if (modelUpper.includes('INFINIX') || modelUpper.includes('TECNO') || modelUpper.includes('ITEL')) {
    general = Math.min(200, general + 3);
    redDot = Math.min(200, redDot + 2);
    optDpi = Math.max(optDpi, 430);
  }

  // Playstyle fine-tuning
  if (playstyle === 'shotgun') {
    // Shotgun (M1887/M1014) requires aggressive vertical flick
    general = Math.min(200, general + 4);
    redDot = Math.min(200, redDot + 2);
    btnSize = Math.max(38, btnSize - 4); // smaller button = larger drag travel
  } else if (playstyle === 'smg') {
    // SMG (MP40/UMP) requires smooth mid drag
    general = Math.min(200, general + 1);
    redDot = Math.min(200, redDot + 3);
    btnSize = Math.max(40, btnSize - 1);
  } else if (playstyle === 'sniper') {
    // Sniper requires controlled scope
    sniperScope = Math.max(90, sniperScope - 15);
    general = Math.max(160, general - 6);
    btnSize = Math.min(52, btnSize + 3);
  } else if (playstyle === 'ar') {
    // AR requires high stability
    scope2 = Math.min(200, scope2 + 2);
    scope4 = Math.min(200, scope4 + 3);
  }

  // Storage optimization advice
  let graphics = 'Smooth + High FPS';
  if (rom.includes('256') || rom.includes('512') || rom.includes('1TB')) {
    graphics = 'Standard / Ultra + High FPS';
  }

  // Pointer speed recommendation
  const pointerSpeed = ram === '2GB RAM' || ram === '3GB RAM' ? 'Maximum (100%)' : 'Fast (75% - 85%)';
  const refreshRate = ram === '2GB RAM' ? '60Hz Standard' : '90Hz / 120Hz Ultra';

  return {
    model: model.trim(),
    ram,
    rom,
    android: android.trim(),
    playstyle,
    general,
    redDot,
    scope2,
    scope4,
    sniperScope,
    freeLook,
    recommendedDpi: optDpi,
    fireButtonSize: btnSize,
    buttonPosition: { x: 74, y: 38 },
    pointerSpeed,
    refreshRate,
    graphics,
    headshotRate,
    timestamp: Date.now()
  };
}
