import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  ShieldCheck,
  LogOut,
  Zap,
  CheckCircle2,
  Share2,
  SlidersHorizontal,
  Flame
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { SensiForm } from './components/SensiForm';
import { SensiResults } from './components/SensiResults';
import { AuthModal } from './components/AuthModal';
import { DragSimulator } from './components/DragSimulator';
import { SavedVault } from './components/SavedVault';
import { DpiModal } from './components/DpiModal';
import { ProTipsModal } from './components/ProTipsModal';
import { ShareModal } from './components/ShareModal';
import { PublishGuideModal } from './components/PublishGuideModal';
import { Language, PlaystyleType, SavedSetup, SensiResult, UserProfile } from './types';
import { calculateSensi } from './utils/sensiCalculator';
import { playClickSound, playGenerateSuccessSound, setSoundEnabled } from './utils/audio';

export default function App() {
  const [lang, setLang] = useState<Language>('bn');
  const [soundOn, setSoundOn] = useState<boolean>(true);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  // Form states
  const [model, setModel] = useState('INFINIX HOT 50');
  const [ram, setRam] = useState('8GB RAM');
  const [rom, setRom] = useState('256GB Storage');
  const [android, setAndroid] = useState('Android 14');
  const [playstyle, setPlaystyle] = useState<PlaystyleType>('all');
  const [error, setError] = useState<string | null>(null);

  // Result state
  const [result, setResult] = useState<SensiResult | null>(null);

  // Modals state
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [isVaultOpen, setIsVaultOpen] = useState(false);
  const [isDpiOpen, setIsDpiOpen] = useState(false);
  const [isTipsOpen, setIsTipsOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isPublishGuideOpen, setIsPublishGuideOpen] = useState(false);

  // Saved setups in localStorage
  const [savedSetups, setSavedSetups] = useState<SavedSetup[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load from localStorage on mount (matching user's tpx_user key)
  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('tpx_user');
      if (storedUser) {
        setUser({
          email: storedUser,
          name: storedUser.split('@')[0],
          loginTime: new Date().toLocaleTimeString()
        });
      }

      const storedSetups = localStorage.getItem('tpx_saved_setups');
      if (storedSetups) {
        setSavedSetups(JSON.parse(storedSetups));
      }
    } catch {
      // Ignore localStorage errors
    }
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  const handleLogin = (newUser: UserProfile) => {
    setUser(newUser);
    try {
      localStorage.setItem('tpx_user', newUser.email);
    } catch {
      // Ignore
    }
    showToast(
      lang === 'bn'
        ? `স্বাগতম! ${newUser.email} সফলভাবে সংযুক্ত হয়েছে।`
        : `Welcome! Connected as ${newUser.email}.`
    );
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem('tpx_user');
    } catch {
      // Ignore
    }
    setUser(null);
    showToast(lang === 'bn' ? 'লগআউট সম্পন্ন হয়েছে।' : 'Logged out successfully.');
  };

  const handleGenerate = () => {
    if (!model.trim() || !ram || !rom || !android.trim()) {
      playClickSound();
      setError(
        lang === 'bn'
          ? 'দয়া করে সব ফিল্ড (Model, RAM, Storage, Android Version) সঠিকভাবে লিখুন!'
          : 'Please fill in all fields (Model, RAM, Storage, Android Version)!'
      );
      return;
    }

    setError(null);
    const newResult = calculateSensi(model, ram, rom, android, playstyle);
    setResult(newResult);
    playGenerateSuccessSound();

    confetti({
      particleCount: 65,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#ff003c', '#00ff88', '#ffffff']
    });

    showToast(
      lang === 'bn'
        ? '২০০ স্কেলের অটো হেডশট অ্যালগরিদম ক্যালকুলেট হয়েছে!'
        : '200 Scale Auto Headshot Sensi generated!'
    );
  };

  const handleSaveSetup = () => {
    if (!result) return;
    playClickSound();

    const newSetup: SavedSetup = {
      id: Date.now().toString(),
      name: `${result.model.toUpperCase()} (${result.ram})`,
      result,
      savedAt: new Date().toLocaleDateString() + ' ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const updated = [newSetup, ...savedSetups.slice(0, 19)];
    setSavedSetups(updated);
    try {
      localStorage.setItem('tpx_saved_setups', JSON.stringify(updated));
    } catch {
      // Ignore
    }

    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 }
    });

    showToast(
      lang === 'bn'
        ? 'আপনার ডিভাইসের জন্য ২০০ স্কেলের পারফেক্ট সেন্সিটিভিটি সেটআপ তৈরি ও সেভ হয়েছে!'
        : 'Your 200 Scale Sensitivity setup has been verified and saved!'
    );
  };

  const handleDeleteSaved = (id: string) => {
    const updated = savedSetups.filter((s) => s.id !== id);
    setSavedSetups(updated);
    try {
      localStorage.setItem('tpx_saved_setups', JSON.stringify(updated));
    } catch {
      // Ignore
    }
    showToast(lang === 'bn' ? 'ফাইল মুছে ফেলা হয়েছে।' : 'Setup removed.');
  };

  const handleLoadSaved = (savedResult: SensiResult) => {
    setModel(savedResult.model);
    setRam(savedResult.ram);
    setRom(savedResult.rom);
    setAndroid(savedResult.android);
    setPlaystyle(savedResult.playstyle);
    setResult(savedResult);
    showToast(
      lang === 'bn'
        ? `${savedResult.model} এর সেন্সি লোড হয়েছে!`
        : `Loaded sensi for ${savedResult.model}!`
    );
  };

  return (
    <div className="min-h-screen flex flex-col justify-between items-center text-[#f1f5f9] relative pb-10 selection:bg-[#ff003c] selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 z-50 px-4 py-2.5 rounded-xl bg-[#12151e] border border-[#00ff88] text-[#00ff88] font-bold text-xs sm:text-sm shadow-2xl flex items-center gap-2 animate-bounce glow-green">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        lang={lang}
        onToggleLang={() => setLang(lang === 'bn' ? 'en' : 'bn')}
        soundEnabled={soundOn}
        onToggleSound={() => {
          const next = !soundOn;
          setSoundOn(next);
          setSoundEnabled(next);
        }}
        user={user}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onLogout={handleLogout}
        savedCount={savedSetups.length}
        onOpenSaved={() => setIsVaultOpen(true)}
        onOpenTips={() => setIsTipsOpen(true)}
        onOpenShare={() => setIsShareOpen(true)}
        onOpenPublishGuide={() => setIsPublishGuideOpen(true)}
      />

      {/* Center Container */}
      <main className="w-full max-w-[490px] px-3 sm:px-4 my-auto pt-2">
        <div className="w-full bg-[#12151e] rounded-2xl border border-[#262c3d] p-5 sm:p-7 shadow-[0_15px_35px_rgba(0,0,0,0.8),0_0_25px_rgba(255,0,60,0.12)] relative">
          
          {/* Header Title Area */}
          <div className="text-center mb-5">
            <h1 className="font-orbitron font-black text-2xl sm:text-3xl tracking-wide uppercase text-white flex items-center justify-center gap-2">
              TPX <span className="text-[#ff003c] text-glow">SANSI</span> VIP
            </h1>
            <p className="text-xs text-[#94a3b8] mt-1 font-orbitron tracking-tight">
              FF 200 Sensitivity Scale Auto Headshot Algorithm
            </p>
          </div>

          {/* Condition: If not logged in, show Auth Screen matching user's HTML */}
          {!user ? (
            <div className="text-center py-6 px-2 animate-fadeIn font-siliguri">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#ff003c]/15 border border-[#ff003c]/30 flex items-center justify-center text-[#ff003c] glow-red">
                <ShieldCheck className="w-9 h-9" />
              </div>
              
              <h2 className="text-lg font-bold text-white mb-2">
                {lang === 'bn' ? 'গুগল দিয়ে লগইন করুন' : 'Sign in with Google'}
              </h2>
              
              <p className="text-xs text-[#94a3b8] leading-relaxed max-w-sm mx-auto mb-5">
                {lang === 'bn'
                  ? 'আপনার ডিভাইস আইডির সাথে VIP Sensi ফাইল কানেক্ট করতে প্রথমে জিমেইল দিয়ে সাইন-ইন করুন।'
                  : 'To link your phone device ID with the VIP Sensi file, please sign in with your Google account first.'}
              </p>

              {/* Google Button */}
              <button
                type="button"
                onClick={() => setIsAuthModalOpen(true)}
                className="w-full bg-white hover:bg-gray-100 text-gray-800 font-bold py-3.5 px-4 rounded-xl shadow-lg flex items-center justify-center gap-3 transition-all duration-200 active:scale-98 cursor-pointer"
              >
                <img
                  src="https://www.svgrepo.com/show/475656/google-color.svg"
                  width="20"
                  height="20"
                  alt="Google"
                />
                <span className="text-sm font-semibold">
                  {lang === 'bn' ? 'Sign in with Google' : 'Sign in with Google'}
                </span>
              </button>

              {/* Direct Bypass button for quick evaluation */}
              <button
                type="button"
                onClick={() => handleLogin({
                  email: 'rahatyamin9@gmail.com',
                  name: 'rahatyamin9',
                  loginTime: new Date().toLocaleTimeString()
                })}
                className="mt-3 text-[11px] text-[#ff003c] hover:underline block mx-auto transition"
              >
                {lang === 'bn' ? '⚡ টেস্ট একাউন্টে ১-ক্লিকে প্রবেশ করুন (rahatyamin9@gmail.com)' : '⚡ Quick Test Login (rahatyamin9@gmail.com)'}
              </button>
            </div>
          ) : (
            /* Logged in Main App Screen */
            <div className="animate-fadeIn">
              {/* User Bar */}
              <div className="flex items-center justify-between bg-white/[0.03] border border-[#262c3d] px-3.5 py-2.5 rounded-xl mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#ff003c] to-[#ff4d79] text-white flex items-center justify-center font-bold text-xs shadow-md">
                    {user.email.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-gray-200 block max-w-[200px] truncate">
                      {user.email}
                    </span>
                    <span className="text-[10px] text-[#00ff88] font-orbitron flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#00ff88]" /> VIP ACTIVATED
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleLogout}
                  className="p-1.5 text-gray-400 hover:text-[#ff003c] hover:bg-[#ff003c]/10 rounded-lg transition"
                  title={lang === 'bn' ? 'লগআউট' : 'Logout'}
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>

              {/* Sensitivity Generator Form */}
              <SensiForm
                model={model}
                setModel={setModel}
                ram={ram}
                setRam={setRam}
                rom={rom}
                setRom={setRom}
                android={android}
                setAndroid={setAndroid}
                playstyle={playstyle}
                setPlaystyle={setPlaystyle}
                onGenerate={handleGenerate}
                error={error}
                lang={lang}
              />

              {/* Result Area */}
              {result && (
                <SensiResults
                  result={result}
                  onSave={handleSaveSetup}
                  onOpenDpiGuide={() => setIsDpiOpen(true)}
                  onOpenSimulator={() => setIsSimulatorOpen(true)}
                  lang={lang}
                />
              )}
            </div>
          )}
        </div>

        {/* Footer Features Bar */}
        <div className="mt-4 flex flex-wrap items-center justify-center gap-3 text-[11px] text-gray-500 font-siliguri">
          <span className="flex items-center gap-1">
            <span className="text-[#00ff88]">✓</span> 100% Anti-Ban (In-Game Settings Only)
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <span className="text-[#ff003c]">✓</span> 200 Scale Free Fire Engine
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <span className="text-yellow-400">✓</span> No Root Required
          </span>
        </div>
      </main>

      {/* Modals */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLogin={handleLogin}
        lang={lang}
      />

      <DragSimulator
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
        result={result}
        lang={lang}
      />

      <SavedVault
        isOpen={isVaultOpen}
        onClose={() => setIsVaultOpen(false)}
        setups={savedSetups}
        onSelectSetup={handleLoadSaved}
        onDeleteSetup={handleDeleteSaved}
        lang={lang}
      />

      <DpiModal
        isOpen={isDpiOpen}
        onClose={() => setIsDpiOpen(false)}
        lang={lang}
      />

      <ProTipsModal
        isOpen={isTipsOpen}
        onClose={() => setIsTipsOpen(false)}
        lang={lang}
      />

      <ShareModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        lang={lang}
      />

      <PublishGuideModal
        isOpen={isPublishGuideOpen}
        onClose={() => setIsPublishGuideOpen(false)}
        lang={lang}
      />
    </div>
  );
}
